#include <string>
using namespace std;

int returnPermutations(string input, string output[]){
if(input[2]=='\0'){string y="";
  output[0]=y+input[0]+input[1];
  output[1]=y+input[1]+input[0];return 2;
}
int k=returnPermutations(input.substr(1),output);
int ans=output[0].length();
  int i,j;char p=input[0];
  for(j=0;j<ans;j++){
  for(i=0;i<k;i++){
    output[i+k+j*k]=output[i];
  }}
  for(j=0;j<ans+1;j++){
for(i=0;i<k;i++){
  output[i+j*k]=output[i+j*k].insert(j,1,p);
}}
return k*(ans+1);
}

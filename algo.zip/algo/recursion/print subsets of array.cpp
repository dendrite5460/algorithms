void print(int input[],int n,int output[],int m){
  if(n==0){
   int i;
    for(i=0;i<m;i++)cout<<output[i]<<" ";
    cout<<endl;return;
  }
  print(input+1,n-1,output,m);
  output[m]=input[0];
  print(input+1,n-1,output,m+1);
  
}

void printSubsetsOfArray(int input[], int size) {
	// Write your code here
   int out[15],m=0;
  print(input,size,out,m);
}

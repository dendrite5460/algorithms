#include <string>
using namespace std;
string abc(int k){
  string p;
  if(k==2)return p="abc";
  if(k==3)return p="def";
   if(k==4)return p="ghi";
   if(k==5)return p="jkl";
   if(k==6)return p="mno"; if(k==1)return p="";
   if(k==7)return p="pqrs"; if(k==0)return p="";
   if(k==8)return p="tuv";
   if(k==9)return p="wxyz";
}
int keypad(int num, string output[]){
if(num==0){
  output[0]="";
  return 1;
} int k=num%10;
 int ans=keypad(num/10,output); 
  string p=abc(k);
  int k1=p.size();
  int i,j;
  for(j=0;j<k1-1;j++){
  for(i=0;i<ans;i++){
    output[i+(j+1)*ans]=output[i];
  }}
  for(j=0;j<k1;j++){
  for(i=0;i<ans;i++){
    output[i+j*ans]=output[i+j*ans]+p[j];
  }}
  
  return k1*ans;
  
}

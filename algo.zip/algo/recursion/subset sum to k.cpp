void print(int input[],int n,int k,int output[],int m){
 if(n==0){
   if(k==0){
     int i;
     for(i=0;i<m;i++)cout<<output[i]<<" ";
     cout<<endl;
     return ;
   }
   else return;
 } 
  
   print(input+1,n-1,k,output,m);
  output[m]=input[0];
print(input+1,n-1,k-input[0],output,m+1);
 


}
void printSubsetSumToK(int input[], int size, int k) {
  int output[100],m=0;
  print(input,size,k,output,m);
 }
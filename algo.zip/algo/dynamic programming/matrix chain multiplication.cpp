int  mult(int *a,int **dp,int i,int j)
  {
    if(i==j)return 0;
    int min1=100000000;
   if(dp[i][j]!=-1)return dp[i][j];
    for(int k=i;k<j;k++)
    { int m=mult(a,dp,i,k)+mult(a,dp,k+1,j)+a[i-1]*a[j]*a[k];
      min1=min(m,min1);
    }
    dp[i][j]=min1;
    return min1;}
int mcm(int* p, int n){
  n=n+1;
int **dp=new int *[n];
    for(int i=0;i<n;i++){
        dp[i]=new int [n];
         }
  for(int i=0;i<n;i++)for(int k=0;k<n;k++)dp[i][k]=-1;
  
    return mult(p,dp,1,n-1);
}
  



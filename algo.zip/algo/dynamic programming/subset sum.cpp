#include <bits/stdc++.h>
using namespace std;
bool subsetsum(int val[],int n,int sum){
    int i,j;bool dp[n+1][sum+1];
    for(i=0;i<=sum;i++)dp[0][i]=false;
    for(i=0;i<=n;i++)dp[i][0]=true;
    for(i=1;i<=n;i++){
        for(j=1;j<=sum;j++){
            dp[i][j]=dp[i-1][j];
            if(j>=val[i-1])
                dp[i][j]=dp[i][j]||dp[i-1][j-val[i-1]];
        }
    }
bool ans=dp[n][sum];
    return ans;}
int main(){int r;cin>>r;int val[r];
           for(int i=0;i<r;i++)cin>>val[i];
 int sum;
   cin>>sum;
    int a=subsetsum(val,r,sum);
           if(a==1)cout<<"Yes"<<endl;
           else
             cout<<"No";
    }



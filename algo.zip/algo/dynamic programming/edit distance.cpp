#include<iostream>
#include<string>
using namespace std;
typedef int ll;
ll lcs1(string m,string n,ll **dp,ll i,ll j){
    if(i==0)return j;
  if(j==0)return i;
  
    if(dp[i][j]!=-1)return dp[i][j];
    if(m[0]==n[0]){
        ll a=lcs1(m.substr(1),n.substr(1),dp,i-1,j-1);dp[i][j]=a;return a;}
    ll o1=1+lcs1(m,n.substr(1),dp,i,j-1);
   ll o2= 1+lcs1(m.substr(1),n,dp,i-1,j);//delete
    ll o3= 1+lcs1(m.substr(1),n.substr(1),dp,i-1,j-1);//replace
    ll b=min(min(o1,o2),o3);
    dp[i][j]=b;return b;
}
int lcs(string s1, string s2){
  ll g=s1.length();ll h=s2.length();
ll **dp= new ll *[g+1];ll i ,j;
    for(i=0;i<=g;i++){
        dp[i]=new ll [h+1];
        for(j=0;j<=h;j++){
            dp[i][j]=-1;
        }
    }
  return lcs1(s1,s2,dp,g,h);

}

int editDistance(string s1, string s2){
 ll a=lcs(s1,s2);
 
  return a;


}

#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main()
{ll t;
 cin>>t;while(t--){
 ll r,c;cin>>r>>c;
 ll i,j;int a[r][c];
 for(i=0;i<r;i++){
for(j=0;j<c;j++){
  cin>>a[i][j];
}}
   a[r-1][c-1]=1;
      for(int i=c-2;i>=0;--i)
      {
         a[r-1][i]=a[r-1][i+1]-a[r-1][i];
         if(a[r-1][i]<=0)//reset condition
            a[r-1][i]=1;
      }
      for(int i=r-2;i>=0;--i)
      {
         a[i][c-1]=a[i+1][c-1]-a[i][c-1];
         if(a[i][c-1]<=0)
            a[i][c-1]=1;
      }
      for(int i=r-2;i>=0;--i){
         for(int j=c-2;j>=0;--j)
         {
            a[i][j]=min(a[i+1][j],a[i][j+1])-a[i][j];
            if(a[i][j]<=0)
               a[i][j]=1;
         }}
      cout<<a[0][0]<<endl;
   }}


int gcd(int a,int b)
{
if(a<b)gcd(b,a);
  if(b==0)return a;
  return gcd(b,a%b);
}


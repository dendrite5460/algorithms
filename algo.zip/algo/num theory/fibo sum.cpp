#define mod 1000000007
#include<iostream>
using namespace std;
typedef unsigned long long ll;
void mult(ll a[][2],ll b[][2]){
ll f,s,t,fo;
  f=(((a[0][0])%mod*(b[0][0])%mod)%mod+((a[0][1])%mod*(b[1][0])%mod)%mod)%mod;
   s=(((a[0][0])%mod*(b[0][1])%mod)%mod+((a[0][1])%mod*(b[1][1])%mod)%mod)%mod;
   t=(((a[1][0])%mod*(b[0][0])%mod)%mod+((a[1][1])%mod*(b[1][0])%mod)%mod)%mod;
   fo=(((a[1][0])%mod*(b[0][1])%mod)%mod+((a[1][1])%mod*(b[1][1])%mod)%mod)%mod;
  b[0][0]=f;
   b[0][1]=s;
   b[1][0]=t;
   b[1][1]=fo;
}
void pow(ll m[][2],ll n){
if(n==0||n==1)return ;
  pow(m,n/2);
  mult(m,m);
  ll a[2][2]={{1,1},{1,0}};
  if(n%2!=0)mult(a,m);
  
}
unsigned long long fiboSum(ll m,ll n)
{
	ll m1[2][2]={{1,1},{1,0}};
pow(m1,m);  
  ll m2[2][2]={{1,1},{1,0}};
  pow(m2,n+1); 
  return ((m2[0][0]-m1[0][0]+mod))%mod;
}


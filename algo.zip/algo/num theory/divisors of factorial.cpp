#include<bits/stdc++.h>
using namespace std;
# define pb push_back
# define max 500001
# define mod 1000000007
typedef long long ll;

vector<int>* sieve(){
  int i,j;vector<int> *p=new vector<int>();
  bool is[max];
  for(i=2;i<=max;i++)is[i]=true;
  is[0]=false;is[1]=false;
  for(i=2;i*i<=max;i++){
if(is[i]==true){
  for(j=i*i;j<=max;j+=i)is[j]=false;
}
  }p->pb(2);
  for(i=3;i<=max;i+=2){if(is[i])p->pb(i);  }
return p;
}

int main(){
  int t,n,i;
  cin>>t;
   vector<int>*p=sieve();
  while(t--){
 cin>>n;
    
ll result=1;
    for(i=0;p->at(i)<=n;i++){
 int k=p->at(i);
      ll count=0;
    while((n/k)!=0){
count=(count+n/k)%mod;
      k=k*p->at(i);
    }
    result=(result*((count+1)%mod))%mod;
    }
 cout<<result<<endl; }
}	
#include<iostream>
using namespace std;
void mult(int a[][2],int b[][2]){
int f,s,t,fo;
  f=a[0][0]*b[0][0]+a[0][1]*b[1][0];
   s=a[0][0]*b[0][1]+a[0][1]*b[1][1];
   t=a[1][0]*b[0][0]+a[1][1]*b[1][0];
   fo=a[1][0]*b[0][1]+a[1][1]*b[1][1];
  b[0][0]=f;
   b[0][1]=s;
   b[1][0]=t;
   b[1][1]=fo;
}
void pow(int m[][2],int n){
if(n==0||n==1)return ;
  pow(m,n/2);
  mult(m,m);
  int a[2][2]={{1,1},{1,0}};
  if(n%2!=0)mult(a,m);
  
}
int main(){int n;cin>>n;
int m[2][2]={{1,1},{1,0}};
pow(m,n-1);  
  cout<<m[0][0];
}



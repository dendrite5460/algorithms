#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
bool a[1000001];
vector<ll>* sieve(){
ll i,j;
  for(i=0;i<1000001;i++)a[i]=true;
  for(i=2;i*i<1000001;i++){
    if(a[i]==true){
      for(j=2*i;j<1000001;j+=i){
        a[j]=false;
      }
    }
  }
  vector<ll> *vp;
  for(i=2;i<1000001;i++){
    if(a[i]==true)
      vp.push_back(i);
  }
  return vp;
}
int main()
{
ll t,l,r,i,j;
  cin>>t;
  vector<ll>*vp=sieve();
  while(t--){
cin>>l>>r;
    bool isp[r-l+1];
  for(i=0;i<=r-l;i++)isp[i]=true;
  for(i=0;vp->at[i]*vp->at[i]<=r;i++){
    ll cp=vp->at[i];
    ll base=(l/cp)*cp;
    if(base<l)base+=cp;
    for(j=base;j<=r;j+=cp){
      isp[j-l]=false;
    }
    if (base==cp){
      isp[base-l]=true;
    }
    
  }
    for(i=0;i<=r-l;i++){
      if(isp[i]==true){
cout<<i+l<<endl;
      }
    }
  
  
  
  
  }
}
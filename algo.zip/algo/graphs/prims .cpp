#include<vector>
#include<iostream>
#include<algorithm>
using namespace std;
#define mod 1000000007
#include <iostream>
#include<algorithm>
#include<vector>
#define ll long long int
#define mod 1000000007
using namespace std;

int findmin(int *weights,int n,bool *visited){
    int i;
    int minv=-1;
    for(i=0;i<n;i++){
        if(!visited[i]&&(minv==-1 ||weights[i]<weights[minv])){
            minv=i;}}
    return minv;}
void prims(vector<pair<int,int> >edges[],int n){
    bool *visited=new bool[n];
    int *parent=new int [n];
    int *weights=new int [n];
    int i;
    for(i=0;i<n;i++){
        visited[i]=false;
        weights[i]=INT_MAX; }
   weights[0]=0;
   parent[0]=-1;
   for(i=0;i<n;i++){
int minv=findmin(weights,n,visited);
visited[minv]=true;
int j;
for(j=0;j<edges[minv].size();j++){ 
    int x=edges[minv][j].first;
    if( !visited[edges[minv][j].first]){
        if(weights[minv]+edges[minv][j].second<weights[x]){
            weights[x]=edges[minv][j].second+weights[minv];
            parent[x]=minv;}
    }}}
   for(i=0;i<n;i++){
    cout<<i<<" weight "<<weights[i]<<endl;
   } }
int main(){
 int n,e;
 cin>>n>>e;
vector<pair<int,int> > a[n];int i;
for(i=0;i<e;i++){
    int f,s,w;
    cin>>f>>s>>w;
    a[f].push_back(make_pair(s,w));
    a[s].push_back(make_pair(f,w));
}
prims(a,n);
}















/*
void heapify(int a[],int i,int n);
void heap_sort(int a[],int n);
void buildheap(int a[],int n){
    for(int i=n/2;i>=0;i--)heapify(a,i,n);
}
void heapify(int a[],int i,int n)
{ int l=2*i+1,r=2*i+2,large=i;
    if(l<n&& a[l]>a[i])large=l;
    if(r<n && a[r]>a[large])large=r;
    if(large!=i)
    {
        swap(a[i],a[large]);
        heapify(a,large,n-1);
    }
}
void heap_sort(int a[],int n){
    buildheap(a,n);int i;
    for(i=n-1;i>=1;i--){
        swap(a[0],a[i]);
        heapify(a,0,i);
    }
}
*/
/*
void merge(int a[],int l,int mid,int h){
    int l1[mid-l+2],r1[h-mid+1];int i,j;
    for(i=l;i<=mid;i++)l1[i-l]=a[i];
    for(i=mid+1;i<=h;i++)r1[i-mid-1]=a[i];
l1[mid-l+1]=INT_MAX;r1[h-mid]=INT_MAX;int k=0;i=0,j=0;
for(k=l;k<=h;k++){
    if(l1[i]<=r1[j])a[k]=l1[i++];
    else
        a[k]=r1[j++];
}
}
void msort(int a[],int l,int h){
if(l<h){
    int mid=(l+h)/2;
    msort(a,l,mid);
    msort(a,mid+1,h);
    merge(a,l,mid,h);
}
}
*/
/*
int lt,gt;
void part(int a[],int l,int h){
int p=a[l];
int i=l;lt=l;gt=h;
while(i<=gt){
    if(a[i]<p){
        swap(a[i],a[lt]);lt++;i++;
    }
    else if(a[i]>p){
        swap(a[i],a[gt]);gt--;
    }
    else if(a[i]==p){
        i++;
    }
}
}
void qsort(int a[],int l,int h){
    if(l<h){
        part(a,l,h);
        qsort(a,l,lt-1);
        qsort(a,gt+1,h);
    }
}
*/
/*
void isort(int a[],int n){
    int i,j,key;
    for(i=1;i<n;i++){
        key=a[i];
        j=i-1;
        while(j>=0 && a[j]>key){
            a[j+1]=a[j];
            j--;
        }
        a[j+1]=key;
    }
}*/
/*
void bsort(int a[],int n){
    int i,j;
    for(j=0;j<n-1;j++){
        for(i=j;i<n-1;i++){
            if(a[i]>a[i+1])swap(a[i],a[i+1]);
        }
    }
}*/
/*
void ssort(int a[],int n){
    int i,j;int in;
    for(i=0;i<n;i++){
         in=i;
         int minx=INT_MAX;
        for(j=i;j<n;j++){
         if(minx>a[j]){
            minx=a[j];in=j;
         }
        }
        swap(a[i],a[in]);
    }
}*/































/*
//incredible hulk hacker blocks
int main(){
    int n;
    cin>>n;
    int i;
    for(i=0;i<n;i++){
        if(n&(1<<i))
            cout<<(1<<i)<<endl;
    }
}

*/
/*#include<iostream>
using namespace std;
//hacker blocks unique no 2
int main() {
int n;cin>>n;
int a[n];
int i,res;
for(i=0;i<n;i++)cin>>a[i];
    res=a[0];
for(i=1;i<n;i++)res=res^a[i];
int x=res;i=0;
while(x>0){
    if(x&1)
    break;
    x=x>>1;
    i++;
}
int j=i;
int res1,p=0;
for(i=0;i<n;i++){
    if(a[i]&(1<<j)){
        if(p==0){
            res1=a[i];p=10;
        }
        else{
            res1=res1^a[i];
        }
    }
    }
int x2=res1^res;
cout<<res1<<" "<<x2;
}
*/




/*#include<iostream>
#include<fstream>
using namespace std;
//codechef paying up
bool sum(int a[],int n,int k,int range)
{int i;int j;
for(i=0;i<=range;i++){
    int sum=0;
    for(j=0;j<n;j++){
        if(i&(1<<j))sum+=a[j];
    }
    if(sum==k){
        return true;
    }
}
return false;}
int main(){
 int n;int k;
 cin>>n>>k;
 int i;int a[n];
 for(i=0;i<n;i++)cin>>a[i];
 int range=(1<<n)-1;
int k1=sum(a,n,k,range);
if(k1==0)cout<<"no"<<endl;
else
    cout<<"yes"<<endl;
}
*/



























//2*2 matrix addn and sub
//student take information and write in file
/*
class stud{
public:
    string name;
    int roll,marks;
    void info(){
        cout<<"enter name"<<endl;
        string n;cin>>n;name=n;
        cout<<"roll no and marks"<<endl;int m,r;cin>>r>>m;
        roll=r;marks=m;
    }
};
int c=0;
int main(){
    stud k[10];
    while(1){
        cout<<"do u want to add or not 1/0"<<endl;int t;cin>>t;
        if(t==0)break;
        else{
            c++;
            cout<<"enter student details "<<c<<endl;
            k[c-1].info();
           fstream f;
           f.open("ki.txt",ios::app);
           f<<" name of student"<<c<<" "<<k[c-1].name<<"\n";
           f<<" roll no is "<<k[c-1].roll<<"\n";
           f<<" marks is "<<k[c-1].marks<<"\n";
        }
    }
}

*/























/*
void add(int **a,int **b,int **c){
    int i,j;
    for(i=0;i<2;i++){
        for(j=0;j<2;j++){
          c[i][j]=a[i][j]+b[i][j];
        }
    }
    for(i=0;i<2;i++){
    for(j=0;j<2;j++){
        cout<<c[i][j]<<" ";
    }
    cout<<endl;
}
cout<<endl;
}
void sub(int **a,int **b,int **c){
     int i,j;
    for(i=0;i<2;i++){
        for(j=0;j<2;j++){
          c[i][j]=a[i][j]-b[i][j];
        }
    }
    for(i=0;i<2;i++){
    for(j=0;j<2;j++){
        cout<<c[i][j]<<" ";
    }
    cout<<endl;
}
cout<<endl;
}
int main(){int n=2;int i,j;
int **a=new int *[n];
for(int i=0;i<n;i++)a[i]=new int [n];
int **b=new int*[n];
for(int i=0;i<n;i++)b[i]=new int [n];
     int **c=new int*[n];
for(int i=0;i<n;i++)c[i]=new int [n];
    cout<<"enter 1st matrix"<<endl;
for(i=0;i<2;i++){
    for(j=0;j<2;j++){
        cin>>a[i][j];
    }
}
 cout<<"enter 2nd matrix"<<endl;
for(i=0;i<2;i++){
    for(j=0;j<2;j++){
        cin>>b[i][j];
    }
}
add(a,b,c);
sub(a,b,c);
for(i=0;i<2;i++)delete a[i];
    delete []a;
for(i=0;i<2;i++)delete b[i];
delete []b;
for(i=0;i<2;i++)delete c[i];
    delete []c;
}

*/


























/*int main(){
fstream f;
f.open("kiran.txt",ios::out|ios::in);string s;
f>>s;
f.seekp(3,ios::beg);
cout<<f.tellp()<<endl;
cout<<s[f.tellp()]<<endl;
while(!f.eof()){
f>>s;
cout<<s<<endl;
}
f.seekp(1,ios::beg);
f<<"nagasaikiran";
f.close();
}
*/




















/*
/program-3
/
class re;class sub;
class stu{
    string name;int age;
public:
     friend int h(stu o1[3],sub o2[3],re &o3);
};
class sub{
    int mt,pyth,oops,subj;
public:
    friend int h(stu o1[3],sub o2[3],re &o3);
};
class re{
    int hi;string n;int age;
    friend int h(stu o1[3],sub o2[3],re &o3);
public:
    void display(){
        cout<<"max marks is "<<hi<<" name is "<<n<<" age is "<<age;
    }
};

int h(stu o1[3],sub o2[3],re &o3){
    for(int i=0;i<3;i++){
        cout<<"enter name and age"<<endl;cin>>o1[i].name>>o1[i].age;}
    for(int i=0;i<3;i++){
        cout<<"enter subj mt,pyth,oops"<<endl;cin>>o2[i].mt>>o2[i].pyth>>o2[i].oops;}
      int a[3];
    for(int i=0;i<3;i++)
        a[i]=o2[i].mt+o2[i].pyth+o2[i].oops;
    int max=0,in=0;
    for(int i=0;i<3;i++){
        if(a[i]>max){max=a[i];in=i;}
    }
    o3.hi=max;o3.n=o1[in].name;o3.age=o1[in].age;
   return 0;}

int main(){stu o[3];sub a[3];re r;
    h(o,a,r);
    r.display();
}



*/

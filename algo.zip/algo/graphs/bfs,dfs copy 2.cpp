#include<iostream>
#include<queue>
using namespace std;
//disconnected graph traversal
void bfs(int **edges,int n,int e,int sv,bool *visited){
queue<int> a;int i;
a.push(sv);
visited[sv]=true;
while(!a.empty()){
	sv=a.front();
	a.pop();
	cout<<sv<<endl;
	for(int i=0;i<n;i++){
		if(edges[sv][i]==1&& visited[i]==false){
			a.push(i);visited[i]=true;
		}
	}
}
for(i=0;i<n;i++)if(visited[i]==false)bfs(edges,n,e,i,visited);
}
void dfs(int **edges,int n,int e,int sv,bool *visited){
	cout<<sv<<endl;
	visited[sv]=true;
for(int i=0;i<n;i++){
	if(edges[sv][i]==1&&visited[i]==false){
		
		dfs(edges,n,e,i,visited);
	}
}
}
int main(){
	int n,e;int i;
	cin>>n>>e;
	int **edges=new int *[n];
	for(int i=0;i<n;i++){edges[i]=new int[n];for(int j=0;j<n;j++)edges[i][j]=0;}
	for(int i=0;i<e;i++){
		int f,s;
		cin>>f>>s;
		edges[f][s]=1;
		edges[s][f]=1;
	}
bool visited[n];
for(i=0;i<n;i++)visited[i]=false;
	dfs(edges,n,e,0,visited);
for(i=0;i<n;i++)if(visited[i]==false)dfs(edges,n,e,i,visited);
	bfs(edges,n,e,0,visited);
}
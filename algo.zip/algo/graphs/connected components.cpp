#include <iostream>
#include<queue>
#include<vector>
#include<algorithm>
using namespace std;
void getpathdfs(int **a,bool *v,int n,int sv,int r[],int &y)
{   v[sv]=true;
    r[y++]=sv;
     for(int i=0;i<n;i++){
        if(a[sv][i]==1){
            if(!v[i])
                getpathdfs(a, v, n, i, r,y);
        }}}
int main(){
    int n,e;
    cin>>n>>e;
    int **a=new int *[n];
    for(int i=0;i<n;i++){
        a[i]=new int [n];
        for(int j=0;j<n;j++)a[i][j]=0;
    }
    int i,j,p,q;int sv=0;
    for(i=0;i<e;i++){
        cin>>p>>q;
        a[p][q]=1;
        a[q][p]=1;
    }
    bool *v=new bool [n];
    for(j=0;j<n;j++)v[j]=false;
    while(1){
        int r[n],y=0,f=0;
        getpathdfs(a, v,n, sv,r,y);
      sort(r,r+y);
        for(int i=0;i<y;i++)cout<<r[i]<<" ";
        cout<<endl;
        for(int i=0;i<n;i++){
            if(v[i]==false){
                sv=i;f=10;
            }
        }
        if(f!=10)break;
    }
    
}











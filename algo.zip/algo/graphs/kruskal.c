#include <iostream>
#include<map>
#include<string.h>
using namespace std;
typedef long long ll;
class edge{public:
    int source,destination,weight;
};
int findparent(int k,int parent[]){
    if(parent[k]==k)return k;
    return findparent(parent[k],parent);
}
bool compare(edge e1,edge e2){
    return e1.weight<e2.weight;
}
void kruskals(edge *edges,int v,int e){
    sort(edges,edges+e,compare);
    edge *output=new edge[v-1];int i;
    int parent[v];
    for(i=0;i<v;i++)parent[i]=i;
    int s,d,count=0;i=0;
    while(count!=v-1){
        s=findparent(edges[i].source,parent);
        d=findparent(edges[i].destination,parent);
        if(s!=d){
            output[count++]=edges[i];parent[s]=d;
        }
        i++;
    }
    for(i=0;i<count;i++){
        if(output[i].source<output[i].destination)
            cout<<output[i].source<<" "<<output[i].destination<<" "<<output[i].weight<<endl;
        else
            cout<<output[i].destination<<" "<<output[i].source<<" "<<output[i].weight<<endl; }   
}
int main()
{
    int v,e,i;
    cin>>v>>e;
    edge *edges=new edge[e];
    for(i=0;i<e;i++){
        int s,d,w;
        cin>>s>>d>>w;
        edges[i].source=s; edges[i].destination=d;edges[i].weight=w;
    }
    kruskals(edges,v,e);
}
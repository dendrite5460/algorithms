#include <stdio.h>
//INSERTION SORT
int main(){
    int a[]={23,59,32,1,341,29};
    int i,j,key;
    for(j=1;j<5;j++){
    key=a[j];
        i=j-1;
        while(i>=0 && a[i]>key ){
            a[i+1]=a[i];
            i=i-1;
            a[i+1]=key;
        }
    }
    for(i=0;i<5;i++)
        printf("%d\n",a[i]);
    
}

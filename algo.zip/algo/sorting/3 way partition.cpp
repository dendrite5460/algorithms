#include<iostream>
#include<string>
using namespace std;
int lg,i,gl;
//3 way partition
void partition(int a[],int l,int h){
    lg=l,i=l,gl=h;
    int p=a[l];
    while(i<=gl){
        if(a[i]<p){
            int t=a[i];
            a[i]=a[lg];
            a[lg]=t;
            lg++,i++;
        }
        
        else  if(a[i]>p){
            int t=a[i];
            a[i]=a[gl];
            a[gl]=t;
            gl--;
        }
        else if(a[i]==p){
            i++;
        }}}
void qs(int a[],int l,int h){
    if(l<h){
        partition(a,l,h);
        qs(a,l,lg-1);
        qs(a,gl+1,h);
        
    }
}
int main(){
    int a[]={63,132,854,51,5,10,54};
    int l=0,h=6;
    qs(a,l,h);
    int i;for(i=0;i<7;i++)cout<<a[i]<<" ";
}















































/*class a{
public:
    int rec(int l,int b){
        return l*b;
    }
};
class b{
public:
    int cube(int a){
        return a*a*a;
    }
};
class c{
public:
    float in(float p,float t,float r){
    return (p*t*r)/100;
}
};
int main(){
    a a1;b b1;c c1;
    while(1){
    cout<<"1.rec area 2.cube volume 3.interest\n";
    int n;cin>>n;
    if(n==1){
        cout<<"enter length breadth";
        int l,b;
        cin>>l>>b;
       cout<< a1.rec(l,b)<<endl;
    }
    if(n==2){
        cout<<"enter side";
        int q;
        cin>>q;
       cout<< b1.cube(q)<<endl;
        }
    if(n==3){
        cout<<"enter prinicipal,time,rate";
        float p,t,w;
        cin>>p>>t>>w;
       cout<< c1.in(p,t,w)<<endl;
    }
    }
}
#include<iostream>
using namespace std;
typedef long long ll;
ll ar[1000001];
ll tab[10][1000001];
void sieve(){
    ll i,j;
    ar[0]=-1;
    for(i=1;i<=1000000;i++)ar[i]=0;
    for(i=2;i<=1000000;i++){
        if(ar[i]==0){
            for(j=i;j<=1000000;j+=i)ar[j]++;
        }
    }
    
    for(i=1;i<=10;i++){
        for(j=0;j<=1000000;j++){
            if(j==1||j==0)tab[i-1][j]=0;
            if(ar[j]==i)
                tab[i-1][j]=tab[i-1][j-1]+1;
            else tab[i-1][j]=tab[i-1][j-1];
        }
    }}
int main(){
    ll t;
    cin>>t;sieve();
    while(t--){
        ll a,b,n;
        cin>>a>>b>>n;
        if(n==0)cout<<1<<endl;
        else cout<<tab[n-1][b]-tab[n-1][a-1]<<endl;
        
    }
    
}
*/

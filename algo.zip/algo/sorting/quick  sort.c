int partition(int input[],int l,int h){
 int i=l,j=h,r=input[l],temp;
  while(i<j){
  while(r>=input[i]&&i<=h)
    i++;
    while(r<input[j])j--;
    if(i<j){
   temp=input[i];
    input[i]=input[j];
    input[j]=temp;}
  }
   temp=input[l];
  input[l]=input[j];
  input[j]=temp;
  
   return j;
}
void quick(int input[],int l,int h){
 if(l>=h)return ;
 int c=partition(input,l,h);
  quick(input,l,c-1);
  quick(input,c+1,h);
}
void quickSort(int input[], int size) {
 quick(input,0,size-1);
}

void merge(int input[],int l,int h,int mid ){
  int l1[mid-l+1],r1[h-mid];
  int i,q=l;
  for(i=0;i<mid-l+1;i++){l1[i]=input[q];q++;}int p=mid+1;
  for(i=0;i<h-mid;i++){
    r1[i]=input[p];p++;
  }
  int j=0,k=l;i=0;
  while(i!=mid-l+1&&j!=h-mid){
    if(l1[i]<=r1[j]){
      input[k]=l1[i];i++;k++;
    }
    else{
      input[k]=r1[j];j++;k++;
    }
  }
  while(i!=mid-l+1){
    input[k]=l1[i];i++;k++;
  }
  while(j!=h-mid){
    input[k]=r1[j];j++;k++;
  }
}
void merge_sort(int input[],int l,int h)
{if(l>=h)return;
 int mid=(l+h)/2;
 merge_sort(input,l,mid);
 merge_sort(input,mid+1,h);
 merge(input,l,h,mid);
}

void mergeSort(int input[], int size){
    // Write your code here
        merge_sort(input,0,size-1);
}
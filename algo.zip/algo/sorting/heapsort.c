#include<stdio.h>
#include<stdlib.h>
//heap sort
void maxheap(int a[],int n){
    if(n>0){
    int i;
    for(i=0;i<n;i++){
        int p=i;
        while(p>0){
            if(a[p]>a[(p-1)/2]){
                int t=a[p];
                a[p]=a[(p-1)/2];
                a[(p-1)/2]=t;
            }
            p=p/2;
        }}
    int q=a[n-1];
    a[n-1]=a[0];
    a[0]=q;
    maxheap(a,n-1);
}
}
int main(){int i,a[]={234,112,1000,4324,5436,656,777,44,2,10};
    
    maxheap(a,10);
    for(i=0;i<10;i++)printf("%d\n",a[i]);
}




















































/*void merge(int a[],int l,int mid ,int h){
    int l1[mid-l+1],r1[h-mid],i,p=l,q=mid+1;
    for(i=0;i<mid-l+1;i++)l1[i]=a[p++];
    for(i=0;i<h-mid;i++)r1[i]=a[q++];
    int j=0,k=l;i=0;
    while(i<mid-l+1 && j<h-mid){
        if(l1[i]<=r1[j])
            a[k++]=l1[i++];
        else
            a[k++]=r1[j++];
    }
    while(i<mid-l+1){
        a[k++]=l1[i++];
    }
    while(j<h-mid){
        a[k++]=r1[j++];
    }
    
}
void msort(int a[],int l,int h){
    if(l<h){
        int mid=(l+h)/2;
        msort(a,l,mid);
        msort(a,mid+1,h);
        merge(a,l,mid,h);
    }
}
void swap(int *a,int *b){
    int t;
    t=*a;
    *a=*b;
    *b=t;
}
int partition(int a[],int l,int h){
    int p=a[l],lt=l,gt=h,i=l;
    while(i<=gt){
        if(a[i]<p){
            swap(&a[i],&a[lt]);i++,lt++;
        }
        if(a[i]>p){
            swap(&a[i],&a[gt]);gt--;
        }
        if(a[i]==p)i++;
        
    }
    return lt;}
void q_sort(int a[],int l,int h){
    if(l<h){
        int c= partition(a,l,h);
        q_sort(a,l,c-1);
        q_sort(a,c+1,h);
    }
}
int main(int argc,char *argv[]){
   
    int a[]={243,32,14,55,344}; int i;
   // for(i=0;i<atoi(argv[1]);i++){
  //      a[i]=rand()%100000+1;
  //  }
    
    q_sort(a,0,4);
   for(i=0;i<5;i++)printf("%d\n",a[i]);
 }
 */





















































 /*#include<stdio.h>
#include<stdlib.h>
struct node{
    struct node *l,*r;
    int data;
};
void insert(struct node ** root,int data){
if(*root==NULL){
        *root=(struct node *)malloc(sizeof(struct node));
        (*root)->data=data;
        (*root)->l=NULL;
        (*root)->r=NULL;}
    else{
        if((*root)->data<data){
            insert(&(*root)->r,data);}
        else{
              insert(&(*root)->l,data);    }}}
void inorder(struct node *root){
    if(root!=NULL){
        inorder(root->l);
        printf("%d\n",root->data);
        inorder(root->r);
    }
}
void search(struct node **root,struct node **par,struct node **x,int *found,int num){
    struct node *q=*root;
   *par=NULL;
    *found=0;
    while(q!=NULL){
        if(q->data==num){
            *x=q;
           *found=1;
            return;}
         *par=q;
        if(q->data>num){
            q=(q)->l;
            }
else
            q=q->r;}}
void del(struct node **root,int num){
    struct node *par=NULL,*x=NULL;int found; struct node *xsucc;
if(*root==NULL)printf("empty");
    search(root,&par,&x,&found,num);
    if(found==0){
        printf("no data to be deleted");
        }
     if((x)->l!=NULL&&(x)->r!=NULL){
       xsucc=x->r;
        while(xsucc->l!=NULL){
            par=xsucc;
            xsucc=xsucc->l;
        }
        x->data=xsucc->data;
        x=xsucc;
        }
    if(x->l==NULL&&x->r==NULL){
        if(par->r==x){
            par->r=NULL;
        }
        else
            par->l=NULL;
        free(x);
        return;
    }
    if(x->l==NULL&x->r!=NULL){
        if(par->l==x){
            par->l=x->r;
        }
        else
            par->r=x->r;
        free(x);
        return;
    }
    if(x->l!=NULL&x->r==NULL){
        if(par->l==x){
            par->l=x->l;
        }
        else
            par->r=x->l;
        free(x);
        return;
    }

}
int main(){int i;int a[]={11,9,13,8,10,12,14,15,7};
    struct node *r=NULL;
    for(i=0;i<9;i++){
        insert(&r,a[i]);}
    inorder(r);
    printf("after del\n");
       del(&r,10);
    inorder(r);
       printf("after del\n");
    del(&r,14);
    inorder(r);
    printf("after del\n");
    del(&r,8);
    inorder(r);
    printf("after del\n");
    del(&r,13);
    inorder(r);

   

    }
*/






























































/*int main(int argc ,char *argv[]){
    FILE *fp=fopen("vdn2.txt","r");
    while((feof(fp))==0){
        char c=fgetc(fp);
        printf("%c",c);
    }
    fclose(fp);
    
    
    
  }

*/

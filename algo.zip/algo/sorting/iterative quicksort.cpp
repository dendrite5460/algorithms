//iterative quick sort
#include<iostream>
#include<stack>
#include<vector>
#include<algorithm>
using namespace std;
int parition(int a[],int l,int h){
    int p=a[l],lt=l,i=l,gt=h;
    while(i<=gt){
    if(a[i]<p){
        swap(a[i],a[lt]);i++,lt++;
    }
    else if(a[i]>p){
                 swap(a[i],a[gt]);
                 gt--;
             }
   else if(a[i]==p)i++;

    }  return lt;}
int main(){
    int n=6,a[]={123,324,41,122,41,4};
         stack<pair<int,int>> stk;
    int s=0,e=n-1;
    stk.push(make_pair(s, e));
    while(!stk.empty()){
        s=stk.top().first,e=stk.top().second;
        int c=parition(a,s,e);
    stk.pop();
    if(s<c-1)
    stk.push(make_pair(s,c-1));
    if(c+1<e)
        stk.push(make_pair(c+1,e));
    
    }
    for (int i=0;i<6;i++)cout<<a[i]<<endl;
}



























/*
#include<iostream>
using namespace std;
//ITERATIVE MERGESORT
void merge(int arr[],int l,int r,int mid){
    int x=r-mid+1,y=r-mid;
    int l1[x],r1[y];int i,j;
    for(i=l;i<=mid;i++)l1[l-i]=arr[i];
    for(i=mid+1;i<=r;i++)r1[i-mid-1]=arr[i];
    int k=0;i=l,j=mid+1;
    while(i<=mid &&j<=r){
        if(l1[i]<r1[j]){
            arr[k]=l1[i];i++,k++;
        }
        else{
            arr[k]=r1[j];j++,k++;
        }
    }
    while(i!=mid){
        arr[k++]=l1[i++];
    }
    while(j!=r){
        arr[k++]=r1[j++];
    }
}
int main(){
    int i,j;
    int ci=0;int arr[]={123,2134,1,3,41,23,654,67};
    for(i=1;i<6;i=2*i-1){
        
    }
    
    
}










































/*#include<iostream>
#include<string>
using namespace std;
#define max 10
int a[max];
int f=-1,r=-1;
int count(){
    int i,c=0;
    for(i=0;i<max;i++){
        if(a[i]>0)c++;
    }return c;
}
void addatbeg(int item){
    if(f==0 && r==max-1){
        cout<<"deque is full";
    }
    if(f==-1){
        f=0,r=0;
    }
    if(r!=max-1){
        int c=count();
        int j,k=r+1;
        for(j=0;j<c;j++){
            a[k]=a[k-1];
            k--;
        }
        a[k]=item;
        }
    else{
        f--;
        a[f]=item;
    }
}
void addatend(int item){int p;
    if(f==0 && r==max-1){
        cout<<"deque is full";}
    if(f==-1){
        f=0,r=0;}
    if(r==max-1){
        int k=f-1;
        for( p=k;p<r;p++){
            a[p]=a[p+1];
        }
        a[p]=item;
        f--;
    }
    else{
        r++;a[r]=item;
    }
}
void delatbeg(){
    
    
}
void delatend(){
    
}
void display(){
    
}

int main(){
    for(int i=0;i<max;i++)a[i]=0;
    
}
/*
#include<iostream>
using namespace std;
int kadane(int a[])
{
    int ci=0,bi=0;
    int i;
    for(i=0;i<7;i++){
        ci=ci+a[i];
        if(ci<0)ci=0;
         if(bi<ci)bi=ci;
    }
    return bi;
}
int main(){int a[]={12,-20,5,32,-15,12,43};
   cout<< kadane(a);
}


#include<iostream>
using namespace std;
int mincost(int a[][3],int i,int j,int e1,int e2,int o[][3]){
    if(i==e1&&j==e2)return a[i][j];
    if(i>e1||j>e2)return INT_MAX;
    if(o[i][j]>-1)return o[i][j];
  int a1=  mincost(a,i+1,j,e1,e2,o);
   int a2= mincost(a,i,j+1,e1,e2,o);
   int a3= mincost(a,i+1,j+1,e1,e2,o);
    o[i][j]=a[i][j]+min(a1,min(a2,a3));
    return o[i][j];

}
int main(){
    int a[][3]={{4,3,2},{1,8,3},{1,1,8}};int i=0,j=0;int o[3][3];
    for(i=0;i<3;i++){
        for(j=0;j<3;j++){
            o[i][j]=-1;
        }
    }
  cout<<  mincost(a,0,0,2,2,o)<<endl;

}
 
 
/*
#include<iostream>
using namespace std;
int main(){
    int a[][3]={{4,3,2},{1,8,3},{1,1,8}},i,j,o[3][3],m=3,n=3;
    o[m-1][n-1]=8;
    for(i=m-2;i>=0;i--){
        o[i][n-1]=a[i][n-1]+o[i+1][n-1];
    }
    for(i=n-2;i>=0;i--){
        o[m-1][i]=a[m-1][i]+o[m-1][i+1];
    }
    for(i=m-2;i>=0;i--){
        for(j=n-2;j>=0;j--){
            o[i][j]=a[i][j]+min(o[i+1][j],min(o[i+1][j+1],o[i][j+1]));
        }}
    cout<<o[0][0];
}*/
















































/*class a{
public:
    int rec(int l,int b){
        return l*b;
    }
};
class b{
public:
    int cube(int a){
        return a*a*a;
    }
};
class c{
public:
    float in(float p,float t,float r){
    return (p*t*r)/100;
}
};
int main(){
    a a1;b b1;c c1;
    while(1){
    cout<<"1.rec area 2.cube volume 3.interest\n";
    int n;cin>>n;
    if(n==1){
        cout<<"enter length breadth";
        int l,b;
        cin>>l>>b;
       cout<< a1.rec(l,b)<<endl;
    }
    if(n==2){
        cout<<"enter side";
        int q;
        cin>>q;
       cout<< b1.cube(q)<<endl;
        }
    if(n==3){
        cout<<"enter prinicipal,time,rate";
        float p,t,w;
        cin>>p>>t>>w;
       cout<< c1.in(p,t,w)<<endl;
    }
    }
}
#include<iostream>
using namespace std;
typedef long long ll;
ll ar[1000001];
ll tab[10][1000001];
void sieve(){
    ll i,j;
    ar[0]=-1;
    for(i=1;i<=1000000;i++)ar[i]=0;
    for(i=2;i<=1000000;i++){
        if(ar[i]==0){
            for(j=i;j<=1000000;j+=i)ar[j]++;
        }
    }
    
    for(i=1;i<=10;i++){
        for(j=0;j<=1000000;j++){
            if(j==1||j==0)tab[i-1][j]=0;
            if(ar[j]==i)
                tab[i-1][j]=tab[i-1][j-1]+1;
            else tab[i-1][j]=tab[i-1][j-1];
        }
    }}
int main(){
    ll t;
    cin>>t;sieve();
    while(t--){
        ll a,b,n;
        cin>>a>>b>>n;
        if(n==0)cout<<1<<endl;
        else cout<<tab[n-1][b]-tab[n-1][a-1]<<endl;
        
    }
    
}
*/

#include <stdio.h>
//SELECTION SORT
int main(){
    int a[]={23,59,32,1,341,29};
    int i,j,small,k=0;
    for(i=0;i<6;i++){
        small=a[i];
        for(j=i;j<5;j++){
            if(small>a[j+1]){
                small=a[j+1];
                k=j+1;}}
        int temp=a[k];
        a[k]=a[i];
        a[i]=temp;}
    for(i=0;i<6;i++)
        printf("%d\n",a[i]);
    }

#include <bits/stdc++.h>
int a[11][11];
bool ispossible(int row,int col,int n){
  //vertical check
  int i,j;
  for(i=row-1;i>=0;i--){
    if(a[i][col]==1)return false;
  }
  //left diagonal check
  for(i=row-1,j=col-1;i>=0&&j>=0;i--,j--){
    if(a[i][j]==1)return false;
    
  }
  //right diagonal check
  for(i=row-1,j=col+1;i>=0&&j<n;i--,j++){
    if(a[i][j]==1)return false;
    }
  return true;
  }
void queen(int row,int n){
if(row==n){
  int i,j;
  for(i=0;i<n;i++){
    for(j=0;j<n;j++){
      cout<<a[i][j]<<" ";}
  }
  cout<<endl;
return;}
  int k;
  for(k=0;k<n;k++){
  if(ispossible(row,k,n)){
    a[row][k]=1;
    queen(row+1,n);
    a[row][k]=0;
  }
}return;
     }
void placeNQueens(int n){
 memset(a,0,n*n*sizeof(int));
  queen(0,n);
 }
int main(){int n;cin>>n;
  placeNQueens(n);
}

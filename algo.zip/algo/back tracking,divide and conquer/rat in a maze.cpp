
int sol[20][20];
void rat(int maze[][20],int sol[][20],int x,int y,int n){
  if(x==n-1&&y==n-1){
int i,j;sol[x][y]=1;
    for(i=0;i<n;i++){
      for(j=0;j<n;j++){
        cout<<sol[i][j]<<" ";
      }}cout<<endl;
  return;}
  
 
  if(x<0||y<0||x>=n||y>=n||maze[x][y]==0||sol[x][y]==1)return;
  
sol[x][y]=1;  
 rat(maze,sol,x-1,y,n); 
 rat(maze,sol,x+1,y,n); 
 rat(maze,sol,x,y-1,n); 
 rat(maze,sol,x,y+1,n); 
  sol[x][y]=0;
  return;
}
void ratInAMaze(int maze[][20], int n){
  rat(maze,sol,0,0,n);
}

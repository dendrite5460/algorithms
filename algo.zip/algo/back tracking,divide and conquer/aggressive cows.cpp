#include<bits/stdc++.h>
using namespace std;
bool check(long long  a[],long long  n,long long  c,long long  mid){
  long long  i,count=1,last=a[0];
  for(i=1;i<n;i++){
    if(a[i]-last>=mid){
      last=a[i];count++;}
     if(count==c)return true;
  }
 
  return false;
}

int main() {
int t;
  cin>>t;
  while(t--){
    long long c,n;cin>>n>>c;
    long long a[n];
    long long i;
    for(i=0;i<n;i++)cin>>a[i];
    sort(a,a+n);
   long long start=0,end=(a[n-1]-a[0]),ans=0,mid;
    while(start<=end){
      mid=start+(end-start)/2;
      if(check(a,n,c,mid)){
        ans=mid;
        start=mid+1;
      }
      else
        end=mid-1;
    }
    cout<<ans<<endl;
    
    
    
    
  }
  
}

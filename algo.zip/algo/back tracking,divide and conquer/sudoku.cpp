#include<bits/stdc++.h>
bool box(int board[][9],int i,int j,int u){
int row,col;
  for(row=0;row<3;row++){
    for(col=0;col<3;col++){
      if(board[row+i][col+j]==u)return false;
    }
  }
  return true;}
bool col(int board[][9],int i,int j,int u){
int p;for(p=0;p<9;p++)if(board[i][p]==u)return false;
  return true;}
bool row(int board[][9],int i,int j,int u){
int p;for(p=0;p<9;p++)if(board[p][j]==u)return false;
  return true;}
bool safe(int board[][9],int i,int j,int u){
if(row(board,i,j,u)&&col(board,i,j,u)&&box(board,i-i%3,j-j%3,u))return true;
  else
    return false;}
bool select(int board[][9],int &i,int&j){
for(i=0;i<9;i++){
  for(j=0;j<9;j++){
    if(board[i][j]==0)return true;
  }
}return false;
}
bool sudokuSolver(int board[][9]){
  int i,j;
if(!select(board,i,j))return true;
  for(int u=1;u<=9;u++) {
       if(safe(board,i,j,u)){
        board[i][j]=u;
         if(sudokuSolver(board))return true;
         board[i][j]=0;
      }
    
  }
return false;
}
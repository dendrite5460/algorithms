#include<bits/stdc++.h>
using namespace std;
bool possible(long long *p,long long mid,long long k,long long n){
long long i,c=0;
  for(i=0;i<n;i++){
    c+=p[i]/mid;
  }
if(c>=k)return true;
  return false;
}
int main() {
long long t;
  cin>>t;
  while(t--){
    long long n,k,i;
    cin>>n>>k;
    long long *p=new long long[n];
    for(i=0;i<n;i++)cin>>p[i];
    sort(p,p+n);long long mid,mk;
    long long min=0,max=p[n-1];
  
    while(min<=max){
       mid=(min+max)/2;
      if(possible(p,mid,k,n)){
        min=mid+1;
        mk=mid;
      }
      else{
        max=mid-1;}
    }
    cout<<mk<<endl;
  }
}
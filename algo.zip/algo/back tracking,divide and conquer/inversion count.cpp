long long merge(int A[],int l,int mid,int r){
long long count=0,temp[r-l+1];
  long long  i=l,j=mid+1,k=0;
  while(i<=mid&&j<=r){
    if(A[i]<=A[j]){
      temp[k++]=A[i++];
    }
    else{temp[k++]=A[j++];
      count+=mid-i+1;
    }
  }
  while(i<=mid){
    temp[k++]=A[i++];
  }
while(j<=r){
    temp[k++]=A[j++];
  }
  for(i=l;i<=r;i++)A[i]=temp[i-l];
  return count;
}
long long merge_sort(int A[],int l,int r){
  if(r>l){
  long long  mid=(l+r)/2;
  long long  a1=merge_sort(A,l,mid);
  long long a2=merge_sort(A,mid+1,r);
   long long a3=   merge(A,l,mid,r);
    return a1+a2+a3;
  
  return 0;
}
long long solve(int A[], int n)
{
  
  long long k=merge_sort(A,0,n-1);
    return k;
}